from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('form.html')

@app.route('/submit', methods=['POST'])
def submit():
    if request.method == 'POST':
        surname = request.form['surname']
        first_name = request.form['first_name']
        email = request.form['email']
        education = request.form['education']
        profession = request.form['profession']
        gender = request.form['gender']
        motivation = request.form['motivation']
        willing_to_stay = request.form.get('willing_to_stay', 'No')

        return f'''
        <h2>Спасибо за заполнение анкеты!</h2>
        <p>Фамилия: {surname}</p>
        <p>Имя: {first_name}</p>
        <p>Email: {email}</p>
        <p>Образование: {education}</p>
        <p>Профессия: {profession}</p>
        <p>Пол: {gender}</p>
        <p>Мотивация: {motivation}</p>
        <p>Готовы ли остаться на Марсе: {willing_to_stay}</p>
        '''

if __name__ == '__main__':
    app.run(debug=True)
